

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Laporan Bulanan Perkembangan Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/">Guru</a></li>
          <li class="breadcrumb-item active">Laporan Bulanan Perkembangan Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="col-12">
        <p>Nama &nbsp:<?php echo e($siswa->nama_lengkap); ?></p>
        <p>Kelas &nbsp &nbsp:<?php echo e($siswa->kelas); ?></p>
      </div>

    <form action="/filter/perkembangan/<?php echo e($id); ?>" method="post">
          <?php echo csrf_field(); ?>
        <div class="col-12" >
        <div class="float-sm-left form-group" >
          <select class="form-control" name="bulan">
          <option value="Semua"<?php echo e($bulan === 'Semua' ? 'selected' : ''); ?>>Pilih Bulan</option>
          <option value="Januari"<?php echo e($bulan === 'Januari' ? 'selected' : ''); ?>>Januari</option>
          <option value="Februari"<?php echo e($bulan === 'Februari' ? 'selected' : ''); ?>>Februari</option>
          <option value="Maret"<?php echo e($bulan === 'Maret' ? 'selected' : ''); ?>>Maret</option>
          <option value="April"<?php echo e($bulan === 'April' ? 'selected' : ''); ?>>April</option>
          <option value="Mei"<?php echo e($bulan === 'Mei' ? 'selected' : ''); ?>>Mei</option>
          <option value="Agustus"<?php echo e($bulan === 'Agustus' ? 'selected' : ''); ?>>Agustus</option>
          <option value="September"<?php echo e($bulan === 'September' ? 'selected' : ''); ?>>September</option>
          <option value="Oktober"<?php echo e($bulan === 'Oktober' ? 'selected' : ''); ?>>Oktober</option>
          <option value="November"<?php echo e($bulan === 'November' ? 'selected' : ''); ?>>November</option>
          <option value="Desember"<?php echo e($bulan === 'Desember' ? 'selected' : ''); ?>>Desember</option>
          </select>
      </div>
      </div>
            <button type="submit" class="btn btn-primary btn-sm m-1 ">Tampil </button>
    </form>
      <!-- /.card-header -->
      <!-- <div class="card-body table table-responsive p-0"" style="height: 400px;">
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap" id="example3">
          <thead>
            <tr >
              <th>NO</th>
              <th>Lingkup Perkembangan</th>
              <th>Kompetisi dan Indikator</th>
              <th>Kegiatan Anak</th>
              <th>Hasil Karya</th>
              <th>Hasil Akhir</th>
              <th>Kesimpulan</th>
            </tr>
          </thead>
          <tbody>
             <tr>
              <td>1</td>
              <td>Nilai Agama dan Moral</td>
              <td>Terbiasa menyebut nama tuhan sebagai pencipta</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>              </td>
            </tr>
            
            <tr>
              <td>2</td>
              <td>Fisik Motorik</td>
              <td>Terbiasa melakukan kegiatan kebersihan diri</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
            </tr>

            <tr>
              <td>3</td>
              <td>Sosial Emosional</td>
              <td>Memiliki perilaku yang bersifat percaya diri</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
            </tr>
            <tr>
              <td>4</td>
              <td>Kognitif</td>
              <td>Mengenal benda dengan mengelompokkan benda di lingkungan</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
            </tr>
            <tr>
              <td>5</td>
              <td>Bahasa</td>
              <td>Terbiasa ramah menyapa siapapun</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
            </tr>
            <tr>
              <td>6</td>
              <td>Seni</td>
              <td>Membuat karya seni sesuai kreatifitasnya</td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td>
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
              <td> 
                <select name="" class="form-control">
                  <option>Pilih Keterangan</option>
                  <option>BB</option>
                  <option>MB</option>  
                  <option>BSH</option>  
                  <option>BSB</option>  
                  </select>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="col-12 p-3">
      <div class="float-sm-right">
        <button type="submit" class="btn btn-block btn-success">Simpan</button>
      </div>
    </div> -->
    <form action="/perkembangan/<?php echo e($id); ?>/<?php echo e($bulan); ?>" method="post">
      <?php echo csrf_field(); ?>
        <div class="col-12 m-1">
          <div class="row bg-primary p-2">
            <div class="col-2">
              <h4>Lingkup Perkembangan</h4>
            </div>
            <div class="col-10">
              <div class="row">
                <div class="col-4">
                <h4>Kompetensi dan Indikator</h4>
                </div>
                <div class="col-2">
                <p>Kegiatan Anak</p>
                </div>
                <div class="col-2">
                <p>Hasil Karya</p>
                </div>
                <div class="col-2">
                <p>Hasil Akhir</p>
                </div>
                <div class="col-2">
                <h4>Kesimpulan</h4>      
                </div>
              </div>
            </div>
          </div>
          <?php $__currentLoopData = $lingkup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row mb-1 bg-info">
            <div class="col-2 mt-2">
              <p><?php echo e($lk->nama); ?></p>
            </div>
            <div class="col-10">
            <?php $__currentLoopData = $kompetensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($k->lingkup_perkembangan==$lk->id): ?>
            <div class="row m-2">
                <div class="col-4">
                <p><?php echo e($k->nama); ?></p>
                </div>
                <div class="col-2">
                  <select name="ka<?php echo e($k->id); ?>" class="form-control" required>
                      <option>Pilih Keterangan</option>
                      <option>BB</option>
                      <option>MB</option>  
                      <option>BSH</option>  
                      <option>BSB</option>  
                  </select>
                </div>
                <div class="col-2">
                  <select name="hk<?php echo e($k->id); ?>" class="form-control" required>
                      <option>Pilih Keterangan</option>
                      <option>BB</option>
                      <option>MB</option>  
                      <option>BSH</option>  
                      <option>BSB</option>  
                  </select>
                </div>
                <div class="col-2">
                  <select name="ha<?php echo e($k->id); ?>" class="form-control" required>
                      <option>Pilih Keterangan</option>
                      <option>BB</option>
                      <option>MB</option>  
                      <option>BSH</option>  
                      <option>BSB</option>  
                  </select>
                </div>
                <div class="col-2">
                  <select name="kesimpulan<?php echo e($k->id); ?>" class="form-control sm" required>
                      <option>Pilih Keterangan</option>
                      <option>Belum Berkembang</option>
                      <option>Mulai Berkembang</option>  
                      <option>Berkembang Sesuai Harapan</option>  
                      <option>Berkembang Sangat Baik</option>  
                  </select>
                </div>
              </div>  
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-12 p-3">
          <div class="float-sm-left">
            <button type="submit" class="btn btn-block btn-success">Simpan</button>
          </div>
        </div>   
    </form>
    <div class="alert alert-info alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h5><i class="icon fas fa-info"></i> Keterangan</h5>
      BB    : Belum berkembang || MB    : Mulai berkembang || BSH   : Berkembang sesuai harapan || BSB   : Berkembang sangat baik
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/guru/perkembangandetail.blade.php ENDPATH**/ ?>