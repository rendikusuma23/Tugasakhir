

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Raport Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/">Guru</a></li>
          <li class="breadcrumb-item active">Raport Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 500px;">
        
        <form action="/guru/inputraport/<?php echo e($id); ?>" method="POST">
          <?php echo csrf_field(); ?>
        
        <div class="float-sm-left form-group">
          <select class="form-control" name="semester">
            <option>Semester</option>
            <option value="Ganjil ">Ganjil</option>
            <option value="Genap">Genap</option>
            </select>
        </div>
        <table class="table table-head-fixed table-hover">
          <thead>
            <tr >
              <th>NO</th>
              <th>Lingkup Perkembangan</th>
              <th>Kompetisi dan Indikator</th>
            </tr>
          </thead>
          <tbody>
            
              <tr>
                <td>1</td>
                <td>Nilai Agama dan Moral</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="NAG" class="form-control"></textarea>
                </td>
              </tr>
              <tr>
                <td>2</td>
                <td>Fisik Motorik</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="fisik_monotorik" class="form-control"></textarea>
                </td>
              </tr>
              <tr>
                <td>3</td>
                <td>Sosial Emosional</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="sosial_emosional" class="form-control"></textarea>
                </td>
              </tr>
              <tr>
                <td>4</td>
                <td>Kognitif</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="kognitif" class="form-control"></textarea>
                </td>
              </tr>
              <tr>
                <td>5</td>
                <td>Bahasa</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="bahasa" class="form-control"></textarea>
                </td>
              </tr>
              <tr>
                <td>6</td>
                <td>Seni</td>
                
                <td>
                  <textarea id="" cols="30" rows="2" name="seni" class="form-control"></textarea>
                </td> 
              </tr>
              <tr>
                <td></td>
                <td></td>
                <td><div class="col-12 p-3">
                  <div class="float-sm-left">
                    <button type="submit" class="btn btn-block btn-success">Simpan</button>
                  </div>
                </div></td>
              </tr>
            </form>
          </tbody>
        </table>
      </div>
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
felixfbecker.php-intellisense
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//guru/raportdetail.blade.php ENDPATH**/ ?>