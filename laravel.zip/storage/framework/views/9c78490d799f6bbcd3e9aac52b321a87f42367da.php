

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Ubah Password</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/">Guru</a></li>
          <li class="breadcrumb-item active">Ubah Password</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>

<?php $__env->stopSection(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//guru/ubahpassword.blade.php ENDPATH**/ ?>