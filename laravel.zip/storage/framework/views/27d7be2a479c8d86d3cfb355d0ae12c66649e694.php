

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tittle'); ?>
Raport | <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Raport Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/">Siswa</a></li>
          <li class="breadcrumb-item active">Raport Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="/filter/raport" method="post">
  <?php echo csrf_field(); ?>      
  
  <div class="float-sm-left form-group">
    <select class="form-control" name="semester">
      <option value="">Semester</option>
      <option value="Ganjil ">Ganjil</option>
      <option value="Genap">Genap</option>
      </select>
  </div>
  <button type="submit" class="btn btn-primary btn-sm m-1 ">Tampil </button>
</form>
      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 450px;">
        <br>
        
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap" id="example2">
          <thead>
            <tr >
              <th>NO</th>
              <th>Lingkup Perkembangan</th>
              <th>Kompetisi dan Indikator</th>

            </tr>
          </thead>
          <tbody>
            <?php
              $no=1;
          ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>1</td>
              <td>Nilai Agama dan Moral</td>
              <td><?php echo e($p->NAG); ?></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Fisik Motorik</td>
              <td><?php echo e($p->fisik_monotorik); ?></td>
            </tr>
            <tr>
              <td>3</td>
              <td>Sosial Emosional</td>
              <td><?php echo e($p->sosial_emosional); ?></td>
            </tr>
            <tr>
              <td>4</td>
              <td>Kognitif</td>
              <td><?php echo e($p->kognitif); ?></td>
            </tr>
            <tr>
              <td>5</td>
              <td>Bahasa</td>
              <td><?php echo e($p->bahasa); ?></td>
            </tr>
            <tr>
              <td>6</td>
              <td>Seni</td>
              <td><?php echo e($p->seni); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/siswa/raport.blade.php ENDPATH**/ ?>