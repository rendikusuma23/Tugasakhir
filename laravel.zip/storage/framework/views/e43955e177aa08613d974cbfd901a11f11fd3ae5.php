

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Tambah data Lingkup Perkembangan</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active"> Tambah Data Lingkup Perkembangan </li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <form action="/operator/kompetisiindikator" method="POST">
      <?php echo csrf_field(); ?>
<div class="card-body">
    <dl class="row ">
      <dl class="input-group mb-3">
        <dt class="col-sm-4">Nama kompetisi indikator</dt>
        <dd class="col-sm-5"><input type="text" name="nama" class="form-control"></dd>
        <dt class="col-sm-4">Lingkup Perkembangan</dt>
        <dd class="col-sm-5">
            <select name="lingkup_perkembangan" class="form-control" >
                <?php $__currentLoopData = $lingkup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <option value="<?php echo e($g->id); ?>"><?php echo e($g->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </dd>
        <dt class="col-sm-4">Bulan</dt>
        <dd class="col-sm-5">
            <select name="bulan" class="form-control">   
                <option>Agustus</option>
                <option>September</option>
                <option>Oktober</option>  
                <option>November</option>  
                <option>Desember</option>
                <option>Januari</option>
                <option>Februari</option>
                <option>Maret</option>
                <option>April</option>
                <option>Mei</option>   
                </select>
        </dd>
      </dl>
      </dl>
      <dt class="col-sm-4"></dt>
      <dd class="col-sm-2">
          <button type="submit" class="btn btn-block btn-success ">Simpan</button>
      </dd>
  </form>
  
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/operator/kompetisiindikator/tambahdata.blade.php ENDPATH**/ ?>