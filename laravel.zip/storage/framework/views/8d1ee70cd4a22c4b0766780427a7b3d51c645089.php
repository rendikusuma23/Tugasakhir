

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Raport Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Guru</a></li>
          <li class="breadcrumb-item active">Raport Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Daftar Siswa</h3><br> <br>

        <div class="float-sm-left form-group">
          <select class="form-control">
          <option>Semua kelompok</option>
          <option>Kelompok A1</option>
          <option>Kelompok A2</option>
          <option>Kelompok A3</option>
          <option>Kelompok A4</option>
          <option>Kelompok B1</option>
          <option>Kelompok B2</option>
          <option>Kelompok B3</option>
          <option>Kelompok B4</option>

          </select>
      </div>
      <div class="float-sm-left form-group">
        <select class="form-control">
        <option>Semester</option>
        <option>Ganjil</option>
        <option>Genap</option>
        </select>
      </div>

      <div class="float-sm-left form-group">
        <select class="form-control">
        <option>Tahun</option>
        <option>2019/2020</option>
        <option>2020/2021</option>
        <option>2021/2022</option>
        </select>
      </div>

      </div>
      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 350px;">
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap">
          <thead>
            <tr >
              <th>NO</th>
              <th>Nama</th>
              <th>No Induk</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no=1;
          ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="clickable-row" data-href="/guru/raport/<?php echo e($p->no_induk); ?>">
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($p->nama_lengkap); ?></td>
            <td><?php echo e($p->no_induk); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
  jQuery(document).ready(function($){
      $(".clickable-row").click(function() {
          window.location = $(this).data("href");
      });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//guru/raport.blade.php ENDPATH**/ ?>