

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Pembayaran</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active">Pembayaran</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Daftar Bulan</h3><br> <br>



      <!-- /.card-header -->
      <div class="card-body ">
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap">
          <thead>
            <tr >
              <th>NO</th>
              <th>Bulan</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr >
              <td>1</td>
              <td>Januari</td>
              <td>
                    <!-- radio -->
                    <div class="form-group clearfix">
                        <div class="form-group clearfix">
                            <div class="d-inline icheck-primary ">
                              <input type="checkbox" id="checkboxPrimary1" >
                              <label for="checkboxPrimary1">
                                  Lunas
                              </label>
                            </div>
                    </div>
                  </div>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td>Februari</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary2" >
                          <label for="checkboxPrimary2">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
              <td>3</td>
              <td>Maret</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary3" >
                          <label for="checkboxPrimary3">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
              <td>4</td>
              <td>April</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary4" >
                          <label for="checkboxPrimary4">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
              <td>5</td>
              <td>Mei</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary5" >
                          <label for="checkboxPrimary5">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
              <td>6</td>
              <td>Juni</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary6" >
                          <label for="checkboxPrimary6">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
              <td>7</td>
              <td>Juli</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary7" >
                          <label for="checkboxPrimary7">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
            <td>8</td>
              <td>Agustus</td>
              <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary8" >
                          <label for="checkboxPrimary8">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
              </td>
            </tr>
            <tr>
            <td>9</td>
                <td>September</td>
                <td>
                    <div class="form-group clearfix">
                        <div class="form-group clearfix">
                            <div class="d-inline icheck-primary ">
                              <input type="checkbox" id="checkboxPrimary9" >
                              <label for="checkboxPrimary9">
                                  Lunas
                              </label>
                            </div>
                    </div>
                  </div>
                </td>
            </tr>
            <tr>
            <td>10</td>
            <td>Oktober</td>
            <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary10" >
                          <label for="checkboxPrimary10">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
            </td>
            </tr>
            <tr>
            <td>11</td>
            <td>November</td>
            <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary11" >
                          <label for="checkboxPrimary11">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
            </td>
            </tr>
            <tr>
            <td>12</td>
            <td>Desember</td>
            <td>
                <div class="form-group clearfix">
                    <div class="form-group clearfix">
                        <div class="d-inline icheck-primary ">
                          <input type="checkbox" id="checkboxPrimary12" >
                          <label for="checkboxPrimary12">
                              Lunas
                          </label>
                        </div>
                </div>
              </div>
            </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- /.card-body -->
    </div>
    
    <!-- /.card -->
  </div>
  <div class="col-2  p-1 float-sm-right">
    <a href=" ">
      <button type="button" class="btn btn-block btn-success btn-sm ">Kirim Peringatan Pembayaran </button>
    </a>
  </div>
</div>
<br>


    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
jQuery(document).ready(function($){
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//operator/bayar.blade.php ENDPATH**/ ?>