

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Detail Data Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active">Detail Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
  <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/operator/datasiswa/<?php echo e($p->id); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="card-body">
      <dl class="row ">
        <dl class="input-group mb-3">
          <dt class="col-sm-4">Nama Siswa</dt>
          <dd class="col-sm-5"><input type="text" name="nama_lengkap" class="form-control" value="<?php echo e($p->nama_lengkap); ?>"></dd>
          <dt class="col-sm-4">Kelas</dt>
          <dd class="col-sm-5"><input type="text" name="kelas" class="form-control" value="<?php echo e($p->kelas); ?>"></dd>
          <dt class="col-sm-4">No INDUK</dt>
          <dd class="col-sm-5"><input type="number" name="no_induk" class="form-control" value="<?php echo e($p->no_induk); ?>"></dd>
          <dt class="col-sm-4">Jenis Kelamin</dt>
          <dd class="col-sm-5">
            <select class="form-control" name="jenis_kelamin" value="<?php echo e($p->jenis_kelamin); ?>">
                <option>Laki-Laki</option>
                <option>Perempuan</option>  
            </select>
          </dd>
          <dt class="col-sm-4">Tempat dan Tanggal Lahir</dt>
          <dd class="col-sm-5"><input type="text" name="ttl" class="form-control" value="<?php echo e($p->ttl); ?>"></dd>
          <dt class="col-sm-4">Agama</dt>
          <dd class="col-sm-5"><input type="text" name="agama" class="form-control" value="<?php echo e($p->agama); ?>"></dd>
          <dt class="col-sm-4">Anak ke</dt>
          <dd class="col-sm-5"><input type="text" name="anak_ke" class="form-control" value="<?php echo e($p->anak_ke); ?>"></dd>
          <dt class="col-sm-4">Nama Orang Tua</dt>
          <dd class="col-sm-5"><input type="text " name="nama_ayah" class="form-control" value="<?php echo e($p->nama_ayah); ?>"></dd>
          <dt class="col-sm-4">Pekerjaan Orang Tua/Wali</dt>
          <dd class="col-sm-5"><input type="text " name="pekerjaan_ayah" class="form-control" value="<?php echo e($p->pekerjaan_ayah); ?>"></dd>
          <dt class="col-sm-4">Email</dt>
          <dd class="col-sm-5"><input type="text " name="email" class="form-control" value="<?php echo e($p->email); ?>"></dd>
          <dt class="col-sm-4">Telephone</dt>
          <dd class="col-sm-5"><input type="number" name="telephone" class="form-control" value="<?php echo e($p->telephone); ?>"></dd>
          <dt class="col-sm-4">Alamat Orang Tua/Wali</dt>
          <dd class="col-sm-5">
            <textarea name="alamat_lengkap" id="" cols="30" rows="5" class="form-control" value="" placeholder="jalan, desa/kelurahan, kecamatan, kabupaten/kota"><?php echo e($p->alamat_lengkap); ?></textarea>
          </dd>
          <dt class="col-sm-4"></dt>
          <dd class="col-sm-2">
              <button type="submit" class="btn btn-block btn-success">Simpan</button>
          </dd>
        </dl>
      </dl>
    </div>
  </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//operator/detailsiswa.blade.php ENDPATH**/ ?>