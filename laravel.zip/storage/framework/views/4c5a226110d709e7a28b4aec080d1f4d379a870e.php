

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Pembayaran SPP</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active">Pembayaran</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Detail Pembayaran SPP</h3><br> <br>
      <p>Nama &nbsp:<?php echo e($siswa->nama_lengkap); ?></p>
      <p>Kelas &nbsp &nbsp:<?php echo e($siswa->kelas); ?></p>

      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 430px;">
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap" id="">
          <thead>
            <tr >
              <th>No</th>
              <th>Bulan</th>
              <th>Tanggal</th>
              <th>Nominal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Januari</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 1): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 1): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 1): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/1">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td>Februari</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 2): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 2): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 2): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/2">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>3</td>
              <td>Maret</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 3): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 3): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 3): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/3">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>4</td>
              <td>April</td>
              <td>

                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 4): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 4): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 4): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/4">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>5</td>
              <td>Mei</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 5): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 5): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 5): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/5">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>6</td>
              <td>Juni</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 6): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 6): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 6): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/6">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>7</td>
              <td>Juli</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 7): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 7): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 7): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/7">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>8</td>
              <td>Agustus</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 8): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 8): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 8): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/8">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>9</td>
              <td>September</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 9): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 9): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 9): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/9">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>10</td>
              <td>Oktober</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 10): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 10): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 10): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/10">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>11</td>
              <td>November</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 11): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 11): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 11): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/11">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>12</td>
              <td>Desember</td>
              <td>
                <?php
                    $status ="Belum Dibayar";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 12): ?>
                <?php
                    $status =$item->tanggal;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="-";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 12): ?>
                <?php
                    $status =$item->spp;
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($status); ?>

              </td>
              <td>
                <?php
                    $status ="belum";
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->bulan == 12): ?>
                <?php
                    $status ="sudah";
                ?> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($status =="sudah"): ?>
                  <button type="button" class="disabled btn btn-warning btn-sm m-1 ">bayar </button>
                <?php else: ?>
                <a href="/operator/pembayaran/bayar/<?php echo e($id); ?>/12">
                  <button type="button" class="btn btn-warning btn-sm m-1 ">bayar </button>
                </a>
                <?php endif; ?>
              </td>
            </tr>

            
          </tbody>
        </table>
      </div>

      <!-- /.card-body -->
    </div>
    
    <!-- /.card -->
  </div>
</div>
<br>


    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
jQuery(document).ready(function($){
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/operator/bayar.blade.php ENDPATH**/ ?>