

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Akun</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active">Akun</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="col-12">
    <div class="card">
      <div class="card-header">

        <div class="float-sm-left form-group">
          <select class="form-control">
          <option>Semua akun</option>
          <option>Siswa</option>
          <option>Guru</option>

          </select>
      </div>
      <br> 

      </div>
      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 400px;">
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap" id="tabeldata">
          <thead>
            <tr >
              <th>NO</th>
              <th>Nama</th>
              <th>Email</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
                $no=1;
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="clickable-row" data-href="/operator/akun/<?php echo e($g->id); ?>">
              <td><?php echo e($no++); ?></td>
            <td><?php echo e($g->name); ?></td>
            <td><?php echo e($g->email); ?></td>
            <td>
              <a href="/operator/akun/<?php echo e($g->id); ?>">
                <button type="button" class="btn btn-warning btn-sm ">Reset akun </button>
              </a>

                
            </td>
            </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/operator/akun.blade.php ENDPATH**/ ?>