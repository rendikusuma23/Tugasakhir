

<?php $__env->startSection('css'); ?>
<!-- SweetAlert2 -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Riwayat Pendaftaran Siswa Baru</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Operator</a></li>
          <li class="breadcrumb-item active">Pendaftaran Siswa Baru</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>

<div class="col-12">
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Data Pendaftaran Siswa Baru</h3><br>
      
      <!-- select --> 
      

    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive p-0" style="height: 400px;">
      <table class="table table-head-fixed text-nowrap" id="tabeldata">
        <thead>
          <tr>
            <th>NO</th>
            <th>NIK</th>
            <th>Nama</th>
            
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $no=1;
          ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($p->NIK_siswa); ?></td>
            <td><?php echo e($p->nama_lengkap); ?></td>
            
            <td>
              <a href="/operator/riwayatpendaftaran/<?php echo e($p->id_jenis); ?>">
                <button type="button" class="btn btn-success btn-sm ">Detail </button>
              </a>
              
              <a href="">
                <button type="button" class="btn btn-danger btn-sm m-1 ">Hapus </button>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
      </table>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  $(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });

    $('.swalDefaultSuccess').click(function() {
      Toast.fire({
        icon: 'success',
        title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
      })
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views/operator/riwayatpendaftaran.blade.php ENDPATH**/ ?>