

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Laporan Bulanan Perkembangan Siswa</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="/admin">Guru</a></li>
          <li class="breadcrumb-item active">Laporan Bulanan Perkembangan Siswa</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
      <!-- /.card-header -->
      <div class="card-body table-responsive p-0" style="height: 400px;">
        <p>Nama   :</p>
        <p>Kelas  :</p>
        <br>
        <table class="table table-head-fixed text-nowrap table-hover text-nowrap">
          <thead>
            <tr >
              <th>NO</th>
              <th>Lingkup Perkembangan</th>
              <th>Kompetisi dan Indikator</th>
              <th>Kegiatan Anak</th>
              <th>Hasil Karya</th>
              <th>Hasil Akhir</th>
              <th>Kesimpulan</th>
            </tr>
          </thead>
          <tbody>
            <tr class="clickable-row" data-href=" ">
              <td>1</td>
              <td>Nilai Agama dan Moral</td>
              <td>Terbiasa menyebut nama tuhan sebagai pencipta</td>
              <td> BSH</td>
              <td>BSH</td>
              <td>BSH</td>
              <td> </td>
            </tr>
            <tr>
              <td>2</td>
              <td>Fisik Motorik</td>
              <td>Terbiasa melakukan kegiatan kebersihan diri</td>
              <td> </td>
              <td> </td>
              <td></td>
              <td> </td>
            </tr>
            <tr>
              <td>3</td>
              <td>Sosial Emosional</td>
              <td>Memiliki perilaku yang bersifat percaya diri</td>
              <td> </td>
              <td></td>
              <td></td>
              <td> </td>
            </tr>
            <tr>
              <td>4</td>
              <td>Kognitif</td>
              <td>Mengenal benda dengan mengelompokkan benda di lingkungan</td>
              <td></td>
              <td></td>
              <td></td>
              <td> </td>
            </tr>
            <tr>
              <td>5</td>
              <td>Bahasa</td>
              <td>Terbiasa ramah menyapa siapapun</td>
              <td></td>
              <td></td>
              <td></td>
              <td> </td>
            </tr>
            <tr>
              <td>6</td>
              <td>Seni</td>
              <td>Membuat karya seni sesuai kreatifitasnya</td>
              <td></td>
              <td></td>
              <td></td>
              <td> </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="col-12 p-3">
      <div class="float-sm-right">
        <a href=" "class="btn btn-block btn-success btn-sm ">Simpan</a>
      </div>
    </div>
    <div class="alert alert-info alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h5><i class="icon fas fa-info"></i> Keterangan</h5>
      BB    : Belum berkembang <br>
      MB    : Mulai berkembang <br>
      BSH   : Berkembang sesuai harapan <br>
      BSB   : Berkembang sangat baik
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rendi kusuma\Tugasakhir\resources\views//guru/perkembangandetail.blade.php ENDPATH**/ ?>