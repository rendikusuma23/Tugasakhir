<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lingkup_perkembangan extends Model
{
    //
    protected $fillable = [
        'id',
        'nama'
    ];
}
